package app.stickerkb

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.io.File

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

object Store {
    fun dir(c: Context) = File(c.filesDir, "stickers").also { it.mkdirs() }
    fun list(c: Context): List<File> =
        dir(c).listFiles { f -> f.extension == "webp" || f.extension == "gif" }?.sortedByDescending { it.lastModified() } ?: emptyList()
    fun code(f: File) = f.nameWithoutExtension
    fun gifSeconds(b: ByteArray): Double {
        if (b.size < 14) return 0.0
        var i = 13
        val flags = b[10].toInt()
        if ((flags and 0x80) != 0) i += 3 * (1 shl ((flags and 7) + 1))
        var cs = 0
        while (i < b.size) {
            when (b[i].toInt() and 0xFF) {
                0x21 -> {
                    if ((b[i + 1].toInt() and 0xFF) == 0xF9) cs += (b[i + 4].toInt() and 0xFF) or ((b[i + 5].toInt() and 0xFF) shl 8)
                    i += 2
                    while (i < b.size && b[i].toInt() != 0) i += (b[i].toInt() and 0xFF) + 1
                    i++
                }
                0x2C -> {
                    val f = b[i + 9].toInt()
                    i += 10
                    if ((f and 0x80) != 0) i += 3 * (1 shl ((f and 7) + 1))
                    i++
                    while (i < b.size && b[i].toInt() != 0) i += (b[i].toInt() and 0xFF) + 1
                    i++
                }
                else -> break
            }
        }
        return cs / 100.0
    }

    // Возвращает null при успехе или текст ошибки
    fun save(c: Context, uri: Uri, code: String): String? = try {
        if (c.contentResolver.getType(uri) == "image/gif") {
            val bytes = c.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            if (bytes.size > 3_000_000) "GIF больше 3 МБ, выбери поменьше"
            else if (gifSeconds(bytes) > 5.5) "GIF длиннее 5 секунд"
            else {
                File(dir(c), "$code.webp").delete()
                File(dir(c), "$code.gif").writeBytes(bytes)
                null
            }
        } else {
            val bmp = c.contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }!!
            val out = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
            val s = minOf(512f / bmp.width, 512f / bmp.height)
            val w = bmp.width * s
            val h = bmp.height * s
            Canvas(out).drawBitmap(bmp, null, RectF((512 - w) / 2, (512 - h) / 2, (512 + w) / 2, (512 + h) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
            val fmt = if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSLESS else Bitmap.CompressFormat.WEBP
            File(dir(c), "$code.gif").delete()
            File(dir(c), "$code.webp").outputStream().use { out.compress(fmt, 90, it) }
            null
        }
    } catch (e: Throwable) { "Не удалось открыть файл" }
}

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var codeIn: EditText
    private var pendingCode = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(32), dp(16), dp(16)) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        root.addView(TextView(this).apply { text = "Стикеры по кодам"; textSize = 24f })
        root.addView(btn("1. Включить клавиатуру") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        root.addView(btn("2. Выбрать клавиатуру") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        codeIn = EditText(this).apply { hint = "Кодовое слово"; setSingleLine() }
        root.addView(codeIn)
        root.addView(btn("3. Добавить стикер или GIF") {
            val code = codeIn.text.toString().trim().lowercase().filter { it.isLetterOrDigit() || it == '_' }
            if (code.isEmpty()) {
                Toast.makeText(this, "Сначала введи кодовое слово", Toast.LENGTH_SHORT).show()
            } else {
                pendingCode = code
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE)
                }, 1)
            }
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req == 1 && res == RESULT_OK && uri != null) {
            val err = Store.save(this, uri, pendingCode)
            Toast.makeText(this, err ?: "Добавлено", Toast.LENGTH_LONG).show()
            if (err == null) codeIn.setText("")
            refresh()
        }
    }

    private fun refresh() {
        list.removeAllViews()
        Store.list(this).forEach { f ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            row.addView(ImageView(this).apply {
                setImageBitmap(BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 4 }))
            }, LinearLayout.LayoutParams(dp(64), dp(64)))
            row.addView(TextView(this).apply { text = Store.code(f); textSize = 18f; setPadding(dp(12), 0, 0, 0) },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply { text = "Удалить"; setOnClickListener { f.delete(); refresh() } })
            list.addView(row)
        }
    }
}
