package app.stickerkb

import android.content.ClipDescription
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File

class Ime : InputMethodService() {
    private var shift = false
    private var ru = false
    private lateinit var strip: LinearLayout
    private lateinit var keys: LinearLayout

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF1E2430.toInt()) }
        val sc = HorizontalScrollView(this)
        strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sc.addView(strip)
        root.addView(sc, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(88)))
        keys = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keys)
        buildKeys()
        refreshStrip()
        return root
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (::strip.isInitialized) refreshStrip()
    }

    override fun onUpdateSelection(a: Int, b: Int, c: Int, d: Int, e: Int, f: Int) {
        super.onUpdateSelection(a, b, c, d, e, f)
        if (::strip.isInitialized) refreshStrip()
    }

    private fun token(): String {
        val t = currentInputConnection?.getTextBeforeCursor(40, 0)?.toString() ?: return ""
        return t.takeLastWhile { !it.isWhitespace() }.lowercase()
    }

    private fun refreshStrip() {
        val tk = token()
        val all = Store.list(this)
        val shown = if (tk.isEmpty()) all else all.filter { Store.code(it).startsWith(tk) }
        strip.removeAllViews()
        if (shown.isEmpty()) {
            strip.addView(TextView(this).apply {
                text = if (all.isEmpty()) "Добавь стикеры в приложении «Стикеры»" else "Нет стикеров по «$tk»"
                setTextColor(0xFF9AA6BB.toInt()); setPadding(dp(12), dp(30), 0, 0)
            })
        }
        shown.forEach { f ->
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(4), dp(6), dp(4)) }
            cell.addView(ImageView(this).apply {
                setImageBitmap(BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 4 }))
            }, LinearLayout.LayoutParams(dp(56), dp(56)))
            cell.addView(TextView(this).apply { text = Store.code(f); textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
            cell.setOnClickListener { send(f, tk) }
            strip.addView(cell)
        }
    }

    private fun send(f: File, tk: String) {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo ?: return
        val mime = if (f.extension == "gif") "image/gif" else "image/webp"
        val mimes = EditorInfoCompat.getContentMimeTypes(info)
        if (mimes.none { ClipDescription.compareMimeTypes(mime, it) }) {
            Toast.makeText(this, "Это поле не принимает стикеры", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = FileProvider.getUriForFile(this, "app.stickerkb.files", f)
        if (Build.VERSION.SDK_INT < 25) grantUriPermission(info.packageName, uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val flags = if (Build.VERSION.SDK_INT >= 25) InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION else 0
        if (tk.isNotEmpty()) ic.deleteSurroundingText(tk.length, 0)
        InputConnectionCompat.commitContent(ic, info, InputContentInfoCompat(uri, ClipDescription(f.name, arrayOf(mime)), null), flags, null)
    }

    private fun key(label: String, weight: Float = 1f, onTap: () -> Unit): View = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 18f; setTextColor(Color.WHITE)
        setBackgroundColor(0xFF2E3647.toInt())
        layoutParams = LinearLayout.LayoutParams(0, dp(46), weight).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
        setOnClickListener { onTap() }
    }

    private fun type(s: String) {
        currentInputConnection?.commitText(s, 1)
        if (shift) { shift = false; buildKeys() }
        refreshStrip()
    }

    private fun ch(s: String): View { val t = if (shift) s.uppercase() else s; return key(t) { type(t) } }

    private fun buildKeys() {
        keys.removeAllViews()
        fun row(vararg v: View) {
            keys.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; v.forEach { addView(it) } })
        }
        val rows = if (ru) listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю") else listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        row(*"1234567890".map { ch(it.toString()) }.toTypedArray())
        row(*rows[0].map { ch(it.toString()) }.toTypedArray())
        row(*rows[1].map { ch(it.toString()) }.toTypedArray())
        val r3 = mutableListOf<View>(key(if (shift) "⬆" else "⇧", 1.5f) { shift = !shift; buildKeys() })
        rows[2].forEach { r3.add(ch(it.toString())) }
        r3.add(key("⌫", 1.5f) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) })
        row(*r3.toTypedArray())
        row(
            key("🌐", 1.2f) { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() },
            key(if (ru) "RU" else "EN", 1.2f) { ru = !ru; buildKeys() },
            key(",") { type(",") },
            key("пробел", 4f) { type(" ") },
            key(".") { type(".") },
            key("⏎", 1.2f) { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) }
        )
    }
}
